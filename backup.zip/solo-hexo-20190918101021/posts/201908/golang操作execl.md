title: golang操作execl
date: '2019-08-29 17:08:00'
updated: '2019-08-29 17:08:00'
tags: [待分类]
permalink: /articles/2019/08/29/1567069680261.html
---
![](https://img.hacpai.com/bing/20190129.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

😰 
